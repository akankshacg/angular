import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-finished',
  templateUrl: './wizard-finished.component.html',
  styleUrls: ['./wizard-finished.component.scss']
})
export class WizardFinishedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
